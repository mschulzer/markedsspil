#
print("")
print("Din algoritme producerede disse rå output-værdier:")
try:
  print("price_choice:", price_choice)
except:
  print("price_choice: Blev ikke korrekt defineret!")

try:
  print("amount_choice:", amount_choice)
except:
  print("amount_choice: Blev ikke korrekt defineret!")