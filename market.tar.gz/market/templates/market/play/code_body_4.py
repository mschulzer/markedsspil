""" Skriv din egen algoritme herunder """

#price_choice = ??
#amount_choice = ??
