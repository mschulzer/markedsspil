""" Algoritme 1  - kan ikke redigeres """

import random

# Vi vælger en tilfældig pris pr. {{ market.product_name_singular }}.
price_choice = random.uniform(prod_cost, max_price)

# Vi vælger at producere et tilfældigt
# antal {{ market.product_name_plural }}
amount_choice = random.randint(0, max_amount)

# Tryk på 'Afprøv kode' gentagne gange, 
# hvis du vil teste algoritmen. 